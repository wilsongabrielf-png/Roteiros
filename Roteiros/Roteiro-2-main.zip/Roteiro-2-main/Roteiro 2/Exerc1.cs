﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roteiro_2
{
    internal class Exerc1
    {
    }
}
class Produto
{
    private string nome;
    private decimal preco;

    public string Nome
    {
        get { return nome; }
    }
    public decimal Preco
    {
        get { return preco; }
        set
        {
            if (value < 0)
            {
                Console.WriteLine("Erro: o preço não pode ser negativo.");
            }
            else
            {
                preco = value;
            }
        }
    }

    public Produto(string nome, decimal preco)
    {
        this.nome = nome;
        Preco = preco;
    }
    public void ExibirDetalhes()
    {
        Console.WriteLine($"Nome: {nome}");
        Console.WriteLine($"Preço: {preco}");
    }
}

class Program
{
    static void Main()
    {
        Produto p = new Produto("Celular", 1500);
        p.ExibirDetalhes();

        p.Preco = -200;
    }
}

