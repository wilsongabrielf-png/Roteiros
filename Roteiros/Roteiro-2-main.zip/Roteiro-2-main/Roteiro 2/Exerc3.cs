﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roteiro_2
{
    internal class Exerc3
    {
    }
}

class Elevador
{
    private int andarAtual;
    private int totalAndares;
    public int TotalAndares
    {
        get { return totalAndares; }
    }
    public int AndarAtual
    {
        get { return andarAtual; }
        private set
        {
            if (value < 0)
            {
                andarAtual = 0;
            }
            else if (value > totalAndares)
            {
                andarAtual = totalAndares;
            }
            else
            {
                andarAtual = value;
            }
        }
    }
    public Elevador(int totalAndares)
    {
        this.totalAndares = totalAndares;
        andarAtual = 0;
    }
    public void Subir()
    {
        AndarAtual++;
    }
    public void Descer()
    {
        AndarAtual--;
    }
}

class Program
{
    static void Main()
    {
        Elevador e = new Elevador(10);

        e.Subir();
        e.Subir();
        Console.WriteLine(e.AndarAtual);

        e.Descer();
        Console.WriteLine(e.AndarAtual); 

        e.Descer();
        e.Descer();
        Console.WriteLine(e.AndarAtual); 
    }
}
