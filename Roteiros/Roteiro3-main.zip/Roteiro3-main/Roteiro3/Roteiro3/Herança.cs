﻿// See https://aka.ms/new-console-template for more information
using System;
class Animal
{
    public string Nome { get; set; }

    public Animal(string nome)
    {
        Nome = nome;
    }

    public virtual void EmitirSom()
    {
        Console.WriteLine("Som genérico do animal");
    }
}
class Cachorro : Animal
{
    public Cachorro(string nome) : base(nome) { }

    public override void EmitirSom()
    {
        Console.WriteLine("Au au");
    }
}
class Program
{
    static void Main(string[] args)
    {
        Animal animal = new Animal("Bicho");
        animal.EmitirSom();

        Cachorro cachorro = new Cachorro("Rex");
        cachorro.EmitirSom();
    }
}
