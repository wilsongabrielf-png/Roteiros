﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        List<IVoar> voadores = new List<IVoar>
        {
            new Pato(),
            new Aguia()
        };

        List<INadar> nadadores = new List<INadar>
        {
            new Pato(),
            new Peixe()
        };

        Console.WriteLine("Animais que voam:");
        foreach (var v in voadores)
        {
            v.Voar();
        }

        Console.WriteLine("\nAnimais que nadam:");
        foreach (var n in nadadores)
        {
            n.Nadar();
        }
    }
}