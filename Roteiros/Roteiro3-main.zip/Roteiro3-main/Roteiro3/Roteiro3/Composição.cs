﻿using System;

public class Item
{
    public string Nome { get; set; }
    public double Preco { get; set; }

    public void ExibirItem()
    {
        Console.WriteLine($"Item: {Nome} - Preço: R$ {Preco}");
    }
}

public class Pedido
{
    private Item item;

    public Pedido()
    {
        item = new Item();
    }

    public void AdicionarItem(string nome, double preco)
    {
        item.Nome = nome;
        item.Preco = preco;
    }

    public void ExibirPedido()
    {
        Console.WriteLine("Pedido criado:");
        item.ExibirItem();
    }
}
class Program
{
    static void Main()
    {
        Pedido pedido = new Pedido();
        pedido.AdicionarItem("Mouse", 150.00);
        pedido.ExibirPedido();
    }
}