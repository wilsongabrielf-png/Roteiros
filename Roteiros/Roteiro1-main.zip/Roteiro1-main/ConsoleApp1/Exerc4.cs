﻿public class ContaBancaria
{
    public string Titular;
    public int NumeroConta;
    public double Saldo;

    public void Depositar(double valor)
    {
        Saldo += valor;
        Console.WriteLine($"Depósito de R${valor} realizado.");
    }

    public void Sacar(double valor)
    {
        if (Saldo >= valor)
        {
            Saldo -= valor;
            Console.WriteLine($"Saque de R${valor} realizado.");
        }
        else
        {
            Console.WriteLine("Saldo insuficiente!");
        }
    }

    public void ExibirSaldo()
    {
        Console.WriteLine($"Titular: {Titular} | Saldo: R${Saldo}");
    }
}

public class Program
{
    public static void Main()
    {
        ContaBancaria c1 = new ContaBancaria
        {
            Titular = "João",
            NumeroConta = 1,
            Saldo = 1000
        };

        ContaBancaria c2 = new ContaBancaria
        {
            Titular = "Maria",
            NumeroConta = 2,
            Saldo = 500
        };

        c1.Sacar(200);
        c1.ExibirSaldo();

        c2.Depositar(300);
        c2.Sacar(1000);
        c2.ExibirSaldo();
    }
}