﻿// See https://aka.ms/new-console-template for more information
public class Pessoa
{
    public string Nome;
    public int Idade;
    public string Cargo;

    public void Apresentar()
    {
        Console.WriteLine($"Olá, meu nome é {Nome}, tenho {Idade} anos e sou {Cargo}.");
    }

    public void InformarSalario()
    {
        string salario = "";

        if (Cargo == "Gerente")
            salario = "R$10.000,00";
        else if (Cargo == "Desenvolvedor")
            salario = "R$5.000,00";
        else if (Cargo == "Estagiario")
            salario = "R$100,00";
        else
            salario = "Cargo não definido";

        Console.WriteLine($"{Nome} ({Cargo}) recebe {salario}");
    }
}

public class Program
{
    public static void Main()
    {
        Pessoa p1 = new Pessoa { Nome = "João", Idade = 30, Cargo = "Gerente" };
        Pessoa p2 = new Pessoa { Nome = "Maria", Idade = 25, Cargo = "Desenvolvedor" };
        Pessoa p3 = new Pessoa { Nome = "Pedro", Idade = 20, Cargo = "Estagiario" };
        Pessoa p4 = new Pessoa { Nome = "Ana", Idade = 28, Cargo = "Desenvolvedor" };

        p1.InformarSalario();
        p2.InformarSalario();
        p3.InformarSalario();
        p4.InformarSalario();
    }
}

