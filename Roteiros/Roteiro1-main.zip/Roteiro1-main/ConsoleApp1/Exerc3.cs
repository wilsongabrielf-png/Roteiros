﻿public class Produto
{
    public string Nome;
    public double Preco;
    public int Quantidade;

    public void ExibirDados()
    {
        Console.WriteLine($"Produto: {Nome} | Preço: R${Preco} | Quantidade: {Quantidade}");
    }

    public double CalcularValorTotal()
    {
        return Preco * Quantidade;
    }
}

public class Program
{
    public static void Main()
    {
        Produto p1 = new Produto { Nome = "Notebook", Preco = 3000, Quantidade = 2 };
        Produto p2 = new Produto { Nome = "Mouse", Preco = 50, Quantidade = 5 };
        Produto p3 = new Produto { Nome = "Teclado", Preco = 150, Quantidade = 3 };

        p1.ExibirDados();
        Console.WriteLine($"Total: R${p1.CalcularValorTotal()}");

        p2.ExibirDados();
        Console.WriteLine($"Total: R${p2.CalcularValorTotal()}");

        p3.ExibirDados();
        Console.WriteLine($"Total: R${p3.CalcularValorTotal()}");
    }
}