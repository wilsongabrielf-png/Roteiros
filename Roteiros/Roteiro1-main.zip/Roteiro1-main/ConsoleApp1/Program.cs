﻿// See https://aka.ms/new-console-template for more information
public class 
    Pessoa
{
    public string Nome;
    public int Idade;

    public void Apresentar()
    {
        Console.WriteLine($"Olá, meu nome é {Nome} e tenho {Idade} anos.");
    }
}
public class Program
{
    public static void Main()
    {
        Pessoa p1 = new Pessoa();

        p1.Idade = 30;
        p1.Nome = "Joao";

        p1.Apresentar();
    }
}
