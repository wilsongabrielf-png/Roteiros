﻿public class Fantasma
{
    public string Nick;
    public string Cor;
    public string Habilidade;

    public void GerarFantasma()
    {
        Console.WriteLine($"Fantasma: {Nick}, Cor: {Cor}, Habilidade: {Habilidade}");
    }

    public void Mover(string direcao)
    {
        Console.WriteLine($"{Nick} se moveu para {direcao}");
    }
}

public class Program
{
    public static void Main()
    {
        Fantasma f1 = new Fantasma
        {
            Nick = "Blinky",
            Cor = "Vermelho",
            Habilidade = "Perseguição"
        };

        f1.GerarFantasma();
        f1.Mover("cima");
    }
}